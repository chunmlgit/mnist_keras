import helper
import numpy as np
import problem_unittests as tests
from collections import Counter
import tensorflow as tf
from tensorflow.contrib import seq2seq

data_dir = './data/simpsons/moes_tavern_lines.txt'
text = helper.load_data(data_dir)
text = text[81:]

view_sentence_range = (0, 10)
print('Dataset stats')
print('Roughly the number of unique words: {}'.format(len({word: None for word in text.split()})))

scenes = text.split('\n\n')
print('Number of scenes: {}'.format(len(scenes)))

sentence_count_per_scene = [scene.count('\n') for scene in scenes]
print('Average number of sentences in each scene: {}'.format(np.average(sentence_count_per_scene)))

sentences = [sentence for scene in scenes for sentence in scene.split('\n')]
print('Number of lines: {}'.format(len(sentences)))

word_count_sentence = [len(sentence.split()) for sentence in sentences]
print('Average number of words in each line: {}'.format(np.average(word_count_sentence)))

print()
print('The sentences {} to {}:'.format(*view_sentence_range))
print('\n'.join(text.split('\n')[view_sentence_range[0]:view_sentence_range[1]]))

def create_lookup_tables(text):
    word_count = Counter(text)
    vocab_to_int = {word:idx for idx, word in enumerate(word_count)}
    int_to_vocab = {idx:word for idx, word in enumerate(word_count)}

    return vocab_to_int, int_to_vocab

tests.test_create_lookup_tables(create_lookup_tables)

def token_lookup():
    return {'.': '||Period||',
            ',': '||Comma||',
            '?': '||Question_Mark||',
            '"': '||Quotation_Mark||',
            ';': '||Semicolon||',
            '!': '||Exclamation_Mark||',
            '(': '||Left_Parenthese||',
            ')': '||Right_Parenthese||',
            '--': '||Dash||',
            '\n': '||Return||'}

tests.test_tokenize(token_lookup)

helper.preprocess_and_save_data(data_dir, token_lookup, create_lookup_tables)

int_text, vocab_to_int, int_to_vocab, token_dict = helper.load_preprocess()

def get_inputs():
    inputs = tf.placeholder(tf.int32, [None, None], name='input')
    targets = tf.placeholder(tf.int32, [None, None], name='target')
    learning_rate = tf.placeholder(tf.float32, name='learning_rate')

    return inputs, targets, learning_rate

tests.test_get_inputs(get_inputs)

def get_init_cell(batch_size, lstm_size):
    num_layers = 2
    def build_cell(rnn_size):
        lstm = tf.contrib.rnn.BasicLSTMCell(lstm_size)

        return lstm

    # Stack up multiple LSTM layers, for deep learning
    cell = tf.contrib.rnn.MultiRNNCell([build_cell(lstm_size) for _ in range(num_layers)])
    initial_state = tf.identity(cell.zero_state(batch_size, tf.float32), name='initial_state')

    return cell, initial_state

tests.test_get_init_cell(get_init_cell)

def get_embed(input_data, vocab_size, embed_dim):
    embedding = tf.Variable(tf.random_uniform((vocab_size, embed_dim), -1, 1))
    embed = tf.nn.embedding_lookup(embedding, input_data)

    return embed

tests.test_get_embed(get_embed)

def build_rnn(cell, inputs):
    outputs, final_state = tf.nn.dynamic_rnn(cell, inputs, dtype=tf.float32)
    final_state = tf.identity(final_state, name='final_state')

    return outputs, final_state

tests.test_build_rnn(build_rnn)

def build_nn(cell, rnn_size, input_data, vocab_size, embed_dim):
    embed_mat = get_embed(input_data, vocab_size, embed_dim)
    outputs, final_state = build_rnn(cell, embed_mat)

    logits = tf.contrib.layers.fully_connected(
        outputs, vocab_size, activation_fn=None,
        weights_initializer=tf.truncated_normal_initializer(stddev=0.1),
        biases_initializer=tf.zeros_initializer())

    return logits, final_state

tests.test_build_nn(build_nn)

def get_batches(int_text, batch_size, seq_length):
    num_of_words = batch_size * seq_length
    n_batches = len(int_text) // num_of_words
    int_text = int_text[:n_batches * num_of_words]
    int_text_temp = int_text.copy()
    int_text_target = np.zeros_like(int_text)
    int_text_target[:-1] = int_text_temp[1:]
    int_text_target[-1] = int_text_temp[0]
    int_text = np.reshape(int_text, (batch_size, -1))
    int_text_target = np.reshape(int_text_target, (batch_size, -1))

    batches = np.zeros((n_batches, 2, batch_size, seq_length))
    for i in range(0, n_batches):
        batches[i, 0, :, :] = int_text[:, i*seq_length:(i+1)*seq_length]
        batches[i, 1, :, :] = int_text_target[:, i*seq_length:(i+1)*seq_length]
    return batches

tests.test_get_batches(get_batches)

num_epochs = 100
batch_size = 256
rnn_size = 512
embed_dim = 256
seq_length = 64
learning_rate = 1e-2
show_every_n_batches = 10

save_dir = './save'

train_graph = tf.Graph()
with train_graph.as_default():
    vocab_size = len(int_to_vocab)
    input_text, targets, lr = get_inputs()
    input_data_shape = tf.shape(input_text)
    cell, initial_state = get_init_cell(input_data_shape[0], rnn_size)
    logits, final_state = build_nn(cell, rnn_size, input_text, vocab_size, embed_dim)

    probs = tf.nn.softmax(logits, name='probs')

    cost = seq2seq.sequence_loss(
        logits,
        targets,
        tf.ones([input_data_shape[0], input_data_shape[1]]))

    optimizer = tf.train.AdamOptimizer(lr)

    gradients = optimizer.compute_gradients(cost)
    capped_gradients = [(tf.clip_by_value(grad, -1., 1.), var) for grad, var in gradients if grad is not None]
    train_op = optimizer.apply_gradients(capped_gradients)

batches = get_batches(int_text, batch_size, seq_length)

with tf.Session(graph=train_graph) as sess:
    sess.run(tf.global_variables_initializer())

    for epoch_i in range(num_epochs):
        state = sess.run(initial_state, {input_text: batches[0][0]})

        for batch_i, (x, y) in enumerate(batches):
            feed = {
                input_text: x,
                targets: y,
                initial_state: state,
                lr: learning_rate}
            train_loss, state, _ = sess.run([cost, final_state, train_op], feed)

            if (epoch_i * len(batches) + batch_i) % show_every_n_batches == 0:
                print('Epoch {:>3} Batch {:>4}/{} train_loss = {:.3f}'.format(
                    epoch_i,
                    batch_i,
                    len(batches),
                    train_loss))
    saver = tf.train.Saver()
    saver.save(sess, save_dir)
    print('Model trained and saved')

helper.save_params((seq_length, save_dir))

_, vocab_to_int, int_to_vocab, token_dict = helper.load_preprocess()
seq_length, load_dir = helper.load_params()

def get_tensors(loaded_graph):
    inputs = loaded_graph.get_tensor_by_name('input:0')
    initial_state = loaded_graph.get_tensor_by_name('initial_state:0')
    final_state = loaded_graph.get_tensor_by_name('final_state:0')
    probs = loaded_graph.get_tensor_by_name('probs:0')
    return inputs, initial_state, final_state, probs

tests.test_get_tensors(get_tensors)

def pick_word(probabilities, int_to_vocab):
    int_word = np.argmax(probabilities)

    return int_to_vocab[int_word]

tests.test_pick_word(pick_word)

gen_length = 200

prime_word = 'moe_szyslak'

loaded_graph = tf.Graph()
with tf.Session(graph=loaded_graph) as sess:
    loader = tf.train.import_meta_graph(load_dir + '.meta')
    loader.restore(sess, load_dir)

    input_text, initial_state, final_state, probs = get_tensors(loaded_graph)

    gen_sentences = [prime_word + ':']
    prev_state = sess.run(initial_state, {input_text: np.array([[1]])})

    for n in range(gen_length):
        dyn_input = [[vocab_to_int[word] for word in gen_sentences[-seq_length:]]]
        dyn_seq_length = len(dyn_input[0])

        probabilities, prev_state = sess.run([probs, final_state],
                                             {input_text: dyn_input,
                                              initial_state: prev_state})

        pred_word = pick_word(probabilities[0][dyn_seq_length - 1], int_to_vocab)

        gen_sentences.append(pred_word)

    tv_script = ' '.join(gen_sentences)
    for key, token in token_dict.items():
        ending = ' ' if key in ['\n', '(', '"'] else ''
        tv_script = tv_script.replace(' ' + token.lower(), key)
    tv_script = tv_script.replace('\n ', '\n')
    tv_script = tv_script.replace('( ', '(')

    print(tv_script)
