from agent import Agent
from monitor import interact
import gym
import numpy as np
import itertools

env = gym.make('Taxi-v2')
ALPHA_MIN = 0.01
ALPHA_MAX = 0.5
EPS_MIN = 0.001
EPS_MAX = 0.005
for alpha, eps in itertools.product(np.arange(ALPHA_MIN, ALPHA_MAX, 0.01), np.arange(EPS_MIN, EPS_MAX, 0.001)):
    agent = Agent(alpha, eps)
    avg_rewards, best_avg_reward = interact(env, agent)
